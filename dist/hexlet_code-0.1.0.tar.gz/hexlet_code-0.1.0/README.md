### Hexlet tests and linter status:
[![Actions Status](https://github.com/ESKolpakov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ESKolpakov/python-project-49/actions)

### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/082653afe0f9d00af50f/maintainability)](https://codeclimate.com/github/ESKolpakov/python-project-49/maintainability)

### Asciinema
* brain-even
[![asciicast](https://asciinema.org/a/zcPfdMmWX1tf4QEreYkFiUQEl.svg)](https://asciinema.org/a/zcPfdMmWX1tf4QEreYkFiUQEl)
* brain-calc
[![asciicast](https://asciinema.org/a/3tbROHDoJsF6KvI3RnVSlbN0P.svg)](https://asciinema.org/a/3tbROHDoJsF6KvI3RnVSlbN0P)
* brain-gcd
[![asciicast](https://asciinema.org/a/VE5i7V04AcRXfHyEHELqDdWRV.svg)](https://asciinema.org/a/VE5i7V04AcRXfHyEHELqDdWRV)
* brain-progression
[![asciicast](https://asciinema.org/a/dDAGHMccZmh6UzaFk0IGevZTC.svg)](https://asciinema.org/a/dDAGHMccZmh6UzaFk0IGevZTC)
