### Hexlet tests and linter status:
[![Actions Status](https://github.com/ESKolpakov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ESKolpakov/python-project-49/actions)

### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/082653afe0f9d00af50f/maintainability)](https://codeclimate.com/github/ESKolpakov/python-project-49/maintainability)

### Asciinema
* brain-games (general gameplay)
[![asciicast](https://asciinema.org/a/KfvfEVDt0mEtyYeFWmpBuR6ld.svg)](https://asciinema.org/a/KfvfEVDt0mEtyYeFWmpBuR6ld)
* brain-even
[![asciicast](https://asciinema.org/a/Hjr6brZT9Fgtf2bHlFh9HQOZz.svg)](https://asciinema.org/a/Hjr6brZT9Fgtf2bHlFh9HQOZz)
* brain-calc
[![asciicast](https://asciinema.org/a/3tbROHDoJsF6KvI3RnVSlbN0P.svg)](https://asciinema.org/a/3tbROHDoJsF6KvI3RnVSlbN0P)
* brain-gcd
[![asciicast](https://asciinema.org/a/VE5i7V04AcRXfHyEHELqDdWRV.svg)](https://asciinema.org/a/VE5i7V04AcRXfHyEHELqDdWRV)
* brain-progression
[![asciicast](https://asciinema.org/a/dDAGHMccZmh6UzaFk0IGevZTC.svg)](https://asciinema.org/a/dDAGHMccZmh6UzaFk0IGevZTC)
* brain-prime
[![asciicast](https://asciinema.org/a/F9SmQ1GGdXsfRFZy9uhU4oSCD.svg)](https://asciinema.org/a/F9SmQ1GGdXsfRFZy9uhU4oSCD)
